
export ACEROOT="/home/fabio/Desktop/ACE"

python3 "$ACEROOT/multiple_antecedents/mul_ant.py" \
  --csv-dir "$ACEROOT/Designs/ibex_alu/3_harm/temporal_instants"




