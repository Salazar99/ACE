
# Automatic generation of autogen.xml
#harm --csv ./adder_8bit_DU.csv --conf autogen.xml --generate-config
#harm --csv ./adder_8bit_DU.csv --conf autogen.xml --max-ass 100 --min-frank 0.5


$ACEROOT/third_party/vcd2csv --vcd $ACEROOT/Designs/ibex_alu/ibex_alu.vcd --clk clk --vcd-ss ibex_alu_tb --dump-to ./ibex_alu.csv

# Manual generation of camellia.xml
harm --csv ./ibex_alu_DU.csv --conf ibex_alu_DU.xml --check-dump-eval temporal_instants