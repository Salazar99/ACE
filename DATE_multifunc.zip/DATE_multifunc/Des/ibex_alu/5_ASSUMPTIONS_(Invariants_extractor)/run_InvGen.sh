
export ACEROOT="/home/fabio/Desktop/ACE"

python3.11 "$ACEROOT/InvGen/InvGen.py" InvTemplates.xml ../4_filtering/filtered_operator_0.csv

python3.11 "$ACEROOT/InvGen/InvGen.py" InvTemplates.xml ../4_filtering/filtered_operator_1.csv

python3.11 "$ACEROOT/InvGen/InvGen.py" InvTemplates.xml ../4_filtering/filtered_operator_3.csv

python3.11 "$ACEROOT/InvGen/InvGen.py" InvTemplates.xml ../4_filtering/filtered_operator_4.csv

python3.11 "$ACEROOT/InvGen/InvGen.py" InvTemplates.xml ../4_filtering/filtered_operator_29.csv


